<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title>Index - Mentor Bootstrap Template</title>
  <meta name="description" content="">
  <meta name="keywords" content="">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Fonts -->
  <link href="https://fonts.googleapis.com" rel="preconnect">
  <link href="https://fonts.gstatic.com" rel="preconnect" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;1,300;1,400;1,500;1,600;1,700;1,800&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Raleway:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Main CSS File -->
  <link href="assets/css/main.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: Mentor
  * Template URL: https://bootstrapmade.com/mentor-free-education-bootstrap-theme/
  * Updated: Jul 07 2025 with Bootstrap v5.3.7
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body class="index-page">

  
<?php
include "Header.php";
?>
  <main class="main">

    <!-- Hero Section -->
    <section id="hero" class="hero section dark-background">

      <img src="assets/img/hero-bg.jpg" alt="" data-aos="fade-in">

      <div class="container">
        <h2 data-aos="fade-up" data-aos-delay="100">Learning Today,<br>Leading Tomorrow</h2>
        <p data-aos="fade-up" data-aos-delay="200">We are team of talented designers making websites with Bootstrap</p>
        <div class="d-flex mt-4" data-aos="fade-up" data-aos-delay="300">
          <a href="courses.html" class="btn-get-started">Get Started</a>
        </div>
      </div>

    </section><!-- /Hero Section -->

    <!-- About Section -->
    <section id="about" class="about section">

      <div class="container">

        <div class="row gy-4">

          <div class="col-lg-6 order-1 order-lg-2" data-aos="fade-up" data-aos-delay="100">
            <img src="assets/img/about.jpg" class="img-fluid" alt="">
          </div>

      <div class="col-lg-6 order-2 order-lg-1 content" data-aos="fade-up" data-aos-delay="200">
  <h3>NETWORK NET – Computer Education Institute</h3>

  <p class="fst-italic">
    ISO 9001:2015 Certified Institute providing complete computer education and professional IT courses.
  </p>

  <ul>
    <li>
      <i class="bi bi-check-circle"></i>
      <span><strong>Corporate Office:</strong> 69, G.T.B. Nagar, Near Bank of Baroda, Delhi – 9</span>
    </li>
    <li>
      <i class="bi bi-check-circle"></i>
      <span><strong>Courses Offered:</strong> Advance Digital Marketing, Web Designing & Development, Graphic Design / DTP, PHP / MySQL, Java, Python, C & C++, Full Stack Developer</span>
    </li>
    <li>
      <i class="bi bi-check-circle"></i>
      <span><strong>Other Programs:</strong> Tally Prime & GST, Advance Excel, VBA & MIS, Power BI, Hardware & Networking, O-Level & CCC, Shorthand</span>
    </li>
  </ul>

  <a href="https://www.networknet.in" class="read-more" target="_blank">
    <span>Visit Website</span>
    <i class="bi bi-arrow-right"></i>
  </a>
</div>


        </div>

      </div>

    </section><!-- /About Section -->

    <!-- Counts Section -->
    <section id="counts" class="section counts light-background">

      <div class="container" data-aos="fade-up" data-aos-delay="100">

        <div class="row gy-4">

          <div class="col-lg-3 col-md-6">
            <div class="stats-item text-center w-100 h-100">
              <span data-purecounter-start="0" data-purecounter-end="1232" data-purecounter-duration="1" class="purecounter"></span>
              <p>Students</p>
            </div>
          </div><!-- End Stats Item -->

          <div class="col-lg-3 col-md-6">
            <div class="stats-item text-center w-100 h-100">
              <span data-purecounter-start="0" data-purecounter-end="64" data-purecounter-duration="1" class="purecounter"></span>
              <p>Courses</p>
            </div>
          </div><!-- End Stats Item -->

          <div class="col-lg-3 col-md-6">
            <div class="stats-item text-center w-100 h-100">
              <span data-purecounter-start="0" data-purecounter-end="42" data-purecounter-duration="1" class="purecounter"></span>
              <p>Events</p>
            </div>
          </div><!-- End Stats Item -->

          <div class="col-lg-3 col-md-6">
            <div class="stats-item text-center w-100 h-100">
              <span data-purecounter-start="0" data-purecounter-end="24" data-purecounter-duration="1" class="purecounter"></span>
              <p>Trainers</p>
            </div>
          </div><!-- End Stats Item -->

        </div>

      </div>

    </section><!-- /Counts Section -->

    <!-- Why Us Section -->
    <section id="why-us" class="section why-us">

      <div class="container">

        <div class="row gy-4">

          <div class="col-lg-4" data-aos="fade-up" data-aos-delay="100">
            <div class="why-box">
             <h3>Why Choose Our Institute?</h3>
<p>
  Network Net is an ISO 9001:2015 Certified Institute committed to providing quality computer education. 
  We offer industry-oriented courses with practical training, experienced faculty, and updated course 
  modules designed to build strong technical and professional skills. Our focus is on real-world 
  applications, career growth, and complete student support.
</p>

              <div class="text-center">
                <a href="#" class="more-btn"><span>Learn More</span> <i class="bi bi-chevron-right"></i></a>
              </div>
            </div>
          </div><!-- End Why Box -->

       <div class="col-lg-8 d-flex align-items-stretch">
  <div class="row gy-4" data-aos="fade-up" data-aos-delay="200">

    <div class="col-xl-4">
      <div class="icon-box d-flex flex-column justify-content-center align-items-center">
        <i class="bi bi-clipboard-data"></i>
        <h4><strong>Industry-Oriented Courses</strong></h4>
        <p>
          We offer <strong>job-focused courses</strong> in
          <strong>Digital Marketing, Web Development, Full Stack Development, Data Analytics</strong>,
          and <strong>Programming</strong> with <strong>practical, real-world training</strong>.
        </p>
      </div>
    </div><!-- End Icon Box -->

    <div class="col-xl-4" data-aos="fade-up" data-aos-delay="300">
      <div class="icon-box d-flex flex-column justify-content-center align-items-center">
        <i class="bi bi-gem"></i>
        <h4><strong>ISO Certified Quality Training</strong></h4>
        <p>
          <strong>Network Net</strong> is an
          <strong>ISO 9001:2015 Certified Institute</strong> ensuring
          <strong>high-quality education</strong>, a
          <strong>structured curriculum</strong>, and
          <strong>professional teaching standards</strong>.
        </p>
      </div>
    </div><!-- End Icon Box -->

    <div class="col-xl-4" data-aos="fade-up" data-aos-delay="400">
      <div class="icon-box d-flex flex-column justify-content-center align-items-center">
        <i class="bi bi-inboxes"></i>
        <h4><strong>Practical Training & Career Support</strong></h4>
        <p>
          <strong>Hands-on lab practice</strong>, <strong>live projects</strong>,
          <strong>flexible batches</strong>, and
          <strong>complete career guidance</strong> help students become
          <strong>job-ready with confidence</strong>.
        </p>
      </div>
    </div><!-- End Icon Box -->

  </div>
</div>


      </div>

    </section><!-- /Why Us Section -->

    <!-- Features Section -->
    <section id="features" class="features section">

     
    </section><!-- /Features Section -->

    <!-- Courses Section -->
    <section id="courses" class="courses section">

      <!-- Section Title -->
      <div class="container section-title" data-aos="fade-up">
        <h2>Courses</h2>
        <p>Popular Courses</p>
      </div><!-- End Section Title -->

      <div class="container">

  <div class="row">

    <!-- Course 1 -->
    <div class="col-lg-4 col-md-6 d-flex align-items-stretch" data-aos="zoom-in" data-aos-delay="100">
      <div class="course-item">
        <img src="assets/img/course/course-1.webp" class="img-fluid" alt="Web Development Course">
        <div class="course-content">

          <div class="d-flex justify-content-between align-items-center mb-3">
            <p class="category"><strong>Web Development</strong></p>
            <p class="price"><strong>₹25,000</strong></p>
          </div>

          <h3><a href="course-details.php"><strong>Website Design & Development</strong></a></h3>

          <p class="description">
            Learn <strong>HTML, CSS, JavaScript, Bootstrap, PHP & MySQL</strong> with
            <strong>hands-on projects</strong> and real-time website creation.
          </p>

          <div class="trainer d-flex justify-content-between align-items-center">
            <div class="trainer-profile d-flex align-items-center">
              <img src="assets/img/person/person-m-7.webp" class="img-fluid" alt="">
              <a href="#" class="trainer-link"><strong>Expert Trainer</strong></a>
            </div>
            <div class="trainer-rank d-flex align-items-center">
              <i class="bi bi-person user-icon"></i>&nbsp;120+
              &nbsp;&nbsp;
              <i class="bi bi-heart heart-icon"></i>&nbsp;200+
            </div>
          </div>

        </div>
      </div>
    </div><!-- End Course Item -->

    <!-- Course 2 -->
    <div class="col-lg-4 col-md-6 d-flex align-items-stretch mt-4 mt-md-0" data-aos="zoom-in" data-aos-delay="200">
      <div class="course-item">
        <img src="assets/img/course/course-2.webp" class="img-fluid" alt="Digital Marketing Course">
        <div class="course-content">

          <div class="d-flex justify-content-between align-items-center mb-3">
            <p class="category"><strong>Digital Marketing</strong></p>
            <p class="price"><strong>₹18,000</strong></p>
          </div>

          <h3><a href="course-details.php"><strong>Advanced Digital Marketing</strong></a></h3>

          <p class="description">
            Master <strong>SEO, Google Ads, Social Media Marketing, Email Marketing</strong>
            with <strong>live campaigns</strong> and certifications.
          </p>

          <div class="trainer d-flex justify-content-between align-items-center">
            <div class="trainer-profile d-flex align-items-center">
              <img src="assets/img/person/person-f-14.webp" class="img-fluid" alt="">
              <a href="#" class="trainer-link"><strong>Certified Expert</strong></a>
            </div>
            <div class="trainer-rank d-flex align-items-center">
              <i class="bi bi-person user-icon"></i>&nbsp;150+
              &nbsp;&nbsp;
              <i class="bi bi-heart heart-icon"></i>&nbsp;260+
            </div>
          </div>

        </div>
      </div>
    </div><!-- End Course Item -->

    <!-- Course 3 -->
    <div class="col-lg-4 col-md-6 d-flex align-items-stretch mt-4 mt-lg-0" data-aos="zoom-in" data-aos-delay="300">
      <div class="course-item">
        <img src="assets/img/course/course-3.webp" class="img-fluid" alt="Accounting Course">
        <div class="course-content">

          <div class="d-flex justify-content-between align-items-center mb-3">
            <p class="category"><strong>Accounting</strong></p>
            <p class="price"><strong>₹15,000</strong></p>
          </div>

          <h3><a href="course-details.php"><strong>Tally Prime with GST</strong></a></h3>

          <p class="description">
            Practical training in <strong>Tally Prime, GST, Income Tax & Accounting</strong>
            with <strong>real business scenarios</strong>.
          </p>

          <div class="trainer d-flex justify-content-between align-items-center">
            <div class="trainer-profile d-flex align-items-center">
              <img src="assets/img/person/person-m-12.webp" class="img-fluid" alt="">
              <a href="#" class="trainer-link"><strong>Industry Professional</strong></a>
            </div>
            <div class="trainer-rank d-flex align-items-center">
              <i class="bi bi-person user-icon"></i>&nbsp;100+
              &nbsp;&nbsp;
              <i class="bi bi-heart heart-icon"></i>&nbsp;180+
            </div>
          </div>

        </div>
      </div>
    </div><!-- End Course Item -->

  </div>

</div>


    </section><!-- /Courses Section -->

    <!-- Trainers Index Section -->
    <section id="trainers-index" class="section trainers-index">

  <div class="container">

    <div class="row">

      <!-- Trainer 1 -->
      <div class="col-lg-4 col-md-6 d-flex" data-aos="fade-up" data-aos-delay="100">
        <div class="member">
          <img src="assets/img/trainers/trainer-1.jpg" class="img-fluid" alt="Web Development Trainer">
          <div class="member-content">
            <h4><strong>Senior Web Development Trainer</strong></h4>
            <span><strong>Web Designing & Full Stack Development</strong></span>
            <p>
              <strong>10+ years of experience</strong> in teaching
              <strong>HTML, CSS, JavaScript, PHP, MySQL</strong> and
              <strong>real-world project development</strong>.
            </p>
            <div class="social">
              <a href="#"><i class="bi bi-linkedin"></i></a>
              <a href="#"><i class="bi bi-facebook"></i></a>
            </div>
          </div>
        </div>
      </div><!-- End Team Member -->

      <!-- Trainer 2 -->
      <div class="col-lg-4 col-md-6 d-flex" data-aos="fade-up" data-aos-delay="200">
        <div class="member">
          <img src="assets/img/trainers/trainer-2.jpg" class="img-fluid" alt="Digital Marketing Trainer">
          <div class="member-content">
            <h4><strong>Digital Marketing Expert</strong></h4>
            <span><strong>SEO, Google Ads & Social Media Marketing</strong></span>
            <p>
              Certified professional with
              <strong>8+ years of industry experience</strong> in
              <strong>live campaigns, analytics, and performance marketing</strong>.
            </p>
            <div class="social">
              <a href="#"><i class="bi bi-linkedin"></i></a>
              <a href="#"><i class="bi bi-instagram"></i></a>
            </div>
          </div>
        </div>
      </div><!-- End Team Member -->

      <!-- Trainer 3 -->
      <div class="col-lg-4 col-md-6 d-flex" data-aos="fade-up" data-aos-delay="300">
        <div class="member">
          <img src="assets/img/trainers/trainer-3.jpg" class="img-fluid" alt="Accounting Trainer">
          <div class="member-content">
            <h4><strong>Accounts & Tally Trainer</strong></h4>
            <span><strong>Tally Prime with GST & Income Tax</strong></span>
            <p>
              Practical trainer with
              <strong>12+ years of experience</strong> in
              <strong>accounting, GST filing, and real business case studies</strong>.
            </p>
            <div class="social">
              <a href="#"><i class="bi bi-linkedin"></i></a>
              <a href="#"><i class="bi bi-facebook"></i></a>
            </div>
          </div>
        </div>
      </div><!-- End Team Member -->

    </div>

  </div>

</section>
<!-- /Trainers Index Section -->

  </main>

    <?php
  include "footer.php";
  ?>

  <!-- Scroll Top -->
  <a href="#" id="scroll-top" class="scroll-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Preloader -->
  <div id="preloader"></div>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>

  <!-- Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>