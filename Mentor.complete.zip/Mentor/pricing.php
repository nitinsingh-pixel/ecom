<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title>Pricing - Mentor Bootstrap Template</title>
  <meta name="description" content="">
  <meta name="keywords" content="">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Fonts -->
  <link href="https://fonts.googleapis.com" rel="preconnect">
  <link href="https://fonts.gstatic.com" rel="preconnect" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;1,300;1,400;1,500;1,600;1,700;1,800&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Raleway:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Main CSS File -->
  <link href="assets/css/main.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: Mentor
  * Template URL: https://bootstrapmade.com/mentor-free-education-bootstrap-theme/
  * Updated: Jul 07 2025 with Bootstrap v5.3.7
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body class="pricing-page">

    <?php
  include "header.php";
  ?>

 <main class="main">

  <!-- Page Title -->
  <div class="page-title" data-aos="fade">
    <div class="heading">
      <div class="container">
        <div class="row d-flex justify-content-center text-center">
          <div class="col-lg-8">
            <h1>Pricing</h1>
            <p class="mb-0">
              Choose a plan that suits your learning needs. All plans include access to expert trainers, practical workshops, and online resources.
            </p>
          </div>
        </div>
      </div>
    </div>
    <nav class="breadcrumbs">
      <div class="container">
        <ol>
          <li><a href="index.html">Home</a></li>
          <li class="current">Pricing</li>
        </ol>
      </div>
    </nav>
  </div><!-- End Page Title -->

  <!-- Pricing Section -->
  <section id="pricing" class="pricing section">

    <div class="container">

      <div class="row gy-3">

        <!-- Free Plan -->
        <div class="col-xl-3 col-lg-6" data-aos="fade-up" data-aos-delay="100">
          <div class="pricing-item">
            <h3>Free</h3>
            <h4><sup>₹</sup>0<span> / month</span></h4>
            <ul>
              <li>Access to basic tutorials</li>
              <li>Community support</li>
              <li>Limited courses</li>
              <li class="na">Certificate of completion</li>
              <li class="na">1-on-1 mentorship</li>
            </ul>
            <div class="btn-wrap">
              <a href="#" class="btn-buy">Get Started</a>
            </div>
          </div>
        </div><!-- End Pricing Item -->

        <!-- Business Plan (Featured) -->
        <div class="col-xl-3 col-lg-6" data-aos="fade-up" data-aos-delay="200">
          <div class="pricing-item featured">
            <h3>Business</h3>
            <h4><sup>₹</sup>1,499<span> / month</span></h4>
            <ul>
              <li>All Free Plan features</li>
              <li>Access to intermediate courses</li>
              <li>Monthly webinars</li>
              <li>Downloadable resources</li>
              <li class="na">Priority support</li>
            </ul>
            <div class="btn-wrap">
              <a href="#" class="btn-buy">Buy Now</a>
            </div>
          </div>
        </div><!-- End Pricing Item -->

        <!-- Developer Plan -->
        <div class="col-xl-3 col-lg-6" data-aos="fade-up" data-aos-delay="300">
          <div class="pricing-item">
            <h3>Developer</h3>
            <h4><sup>₹</sup>2,299<span> / month</span></h4>
            <ul>
              <li>All Business Plan features</li>
              <li>Advanced coding courses</li>
              <li>Project-based learning</li>
              <li>Certificate of excellence</li>
              <li>Mentor feedback sessions</li>
            </ul>
            <div class="btn-wrap">
              <a href="#" class="btn-buy">Buy Now</a>
            </div>
          </div>
        </div><!-- End Pricing Item -->

        <!-- Ultimate Plan -->
        <div class="col-xl-3 col-lg-6" data-aos="fade-up" data-aos-delay="400">
          <div class="pricing-item">
            <span class="advanced">Advanced</span>
            <h3>Ultimate</h3>
            <h4><sup>₹</sup>3,499<span> / month</span></h4>
            <ul>
              <li>All Developer Plan features</li>
              <li>Personalized mentoring</li>
              <li>1-on-1 career guidance</li>
              <li>Exclusive workshops</li>
              <li>Lifetime access to materials</li>
            </ul>
            <div class="btn-wrap">
              <a href="#" class="btn-buy">Buy Now</a>
            </div>
          </div>
        </div><!-- End Pricing Item -->

      </div>

    </div>

  </section><!-- /Pricing Section -->

</main>

    <?php
  include "footer.php";
  ?>
  <!-- Scroll Top -->
  <a href="#" id="scroll-top" class="scroll-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Preloader -->
  <div id="preloader"></div>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>

  <!-- Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>