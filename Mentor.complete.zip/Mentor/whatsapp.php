<?php
if (isset($_POST['send'])) {

    $name    = urlencode($_POST['name']);
    $email   = urlencode($_POST['email']);
    $subject = urlencode($_POST['subject']);
    $message = urlencode($_POST['message']);

    $phone = "919319264317"; // country code included

    $text = "Name: $name\nEmail: $email\nSubject: $subject\nMessage: $message";

    $url = "https://wa.me/$phone?text=" . urlencode($text);

    header("Location: $url");
    exit();
}
?>
