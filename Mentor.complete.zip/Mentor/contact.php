<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title>Contact - Mentor Bootstrap Template</title>
  <meta name="description" content="">
  <meta name="keywords" content="">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Fonts -->
  <link href="https://fonts.googleapis.com" rel="preconnect">
  <link href="https://fonts.gstatic.com" rel="preconnect" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;1,300;1,400;1,500;1,600;1,700;1,800&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Raleway:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Main CSS File -->
  <link href="assets/css/main.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: Mentor
  * Template URL: https://bootstrapmade.com/mentor-free-education-bootstrap-theme/
  * Updated: Jul 07 2025 with Bootstrap v5.3.7
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body class="contact-page">

    <?php
  include "header.php";
  ?>

 <main class="main">

  <!-- Page Title -->
  <div class="page-title">
    <div class="heading">
      <div class="container text-center">
        <h1>Contact Us</h1>
        <p class="mb-0">
          Network Net – ISO 9001:2015 Certified Institute for Complete Computer Education
        </p>
      </div>
    </div>
  </div>

  <!-- Contact Section -->
  <section id="contact" class="contact section">

    <!-- Google Map (GTB Nagar, Delhi) -->
    <div class="mb-5">
      <iframe
        style="border:0; width: 100%; height: 320px;"
        src="https://www.google.com/maps?q=GTB%20Nagar%20Delhi&output=embed"
        allowfullscreen
        loading="lazy">
      </iframe>
    </div>

    <div class="container">

      <div class="row gy-4">

        <!-- Contact Info -->
        <div class="col-lg-4">

          <div class="info-item d-flex mb-4">
            <i class="bi bi-geo-alt"></i>
            <div>
              <h3>Address</h3>
              <p>
                69, G.T.B. Nagar,<br>
                Near Bank of Baroda,<br>
                Delhi – 9
              </p>
            </div>
          </div>

          <div class="info-item d-flex mb-4">
            <i class="bi bi-telephone"></i>
            <div>
              <h3>Call Us</h3>
              <p>
                +91 7011708554<br>
                +91 9999279515<br>
                +91 9350090607
              </p>
            </div>
          </div>

          <div class="info-item d-flex mb-4">
            <i class="bi bi-envelope"></i>
            <div>
              <h3>Email Us</h3>
              <p>networknets@gmail.com</p>
            </div>
          </div>

          <div class="info-item d-flex">
            <i class="bi bi-globe"></i>
            <div>
              <h3>Website</h3>
              <p>
                <a href="https://www.networknet.in" target="_blank">www.networknet.in</a><br>
                <a href="https://www.networknets.com" target="_blank">www.networknets.com</a>
              </p>
            </div>
          </div>

        </div>

        <!-- Contact Form -->
        <form action="whatsapp.php" method="POST">
  <div class="row gy-4">

    <div class="col-md-6">
      <input type="text" name="name" class="form-control" placeholder="Your Name" required>
    </div>

    <div class="col-md-6">
      <input type="email" name="email" class="form-control" placeholder="Your Email" required>
    </div>

    <div class="col-md-12">
      <input type="text" name="subject" class="form-control" placeholder="Subject" required>
    </div>

    <div class="col-md-12">
      <textarea name="message" class="form-control" rows="6" placeholder="Message" required></textarea>
    </div>

    <div class="col-md-12 text-center">
      <button type="submit" name="send">Send Message</button>
    </div>

  </div>
</form>

      </div>

    </div>
  </section>

</main>


    <?php
  include "footer.php";
  ?>

  <!-- Scroll Top -->
  <a href="#" id="scroll-top" class="scroll-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Preloader -->
  <div id="preloader"></div>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>

  <!-- Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>